﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldenShelf.Models
{
    public class Category
    {
        public string CategoryName { get; set; }
        public string CategoryImage { get; set; }
    }
}

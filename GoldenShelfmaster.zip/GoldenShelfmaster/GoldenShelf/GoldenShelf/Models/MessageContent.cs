﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldenShelf.Models
{
    public class MessageContent
    {
        public string Content { get; set; }
        public string Location { get; set; }

        public string ContentBackgroundColor { get; set; }
    }
}
